This directory contains files used in generating distribution releases.
It is not needed for using the software contained in the distribution.
