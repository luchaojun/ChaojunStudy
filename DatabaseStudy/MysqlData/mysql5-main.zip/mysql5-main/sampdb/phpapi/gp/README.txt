index.php
    Grade-keeping project home page
score_entry.php
    Script for performing score entry
